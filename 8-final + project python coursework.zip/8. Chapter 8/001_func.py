marks=[45,76,89,34]
percentage=(sum(marks)/4)

marks2=[34,45,67,89]
perc2=(sum(marks)/4)

print(percentage,perc2)