from operator import truediv
import random



def game(a,b):
    if a==b:
        return None
    elif a=='r':
        if b=='s':
            return False
        elif b=='p':
            return True
    elif a=='p':
        if b=='s':
            return False
        elif b=='r':
            return True
    elif a=='s':
        if b=='r':
            return False
        elif b=='p':
            return True
                


randNo = random.randint(1,3)
print(randNo)
if randNo == 1:
    comp='r'
elif randNo ==2:
    comp='p'
else:
    comp='s'    

you=input("rock(r), paper(p) or scissors(s)")

print(f"Computer chose {comp}")
print(f"you chose {you}")

x=game(comp,you)
if x== None:
    print("The game is a tie")
elif x== True:
    print("you lose")
else:
    print("You win")

