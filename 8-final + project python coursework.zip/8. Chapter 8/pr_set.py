# def max(a,b,c):
#     if(a>b):
#         if(a>c):
#             return a
#         else:
#             return c
#     else:
#         if(b>c):
#             return b
#         else:
#             return c

# maximum=max(4,5,1)
# print(maximum)

def conv(x):
    return (x*(9/5)+32)

c=conv(45)
print(c)
