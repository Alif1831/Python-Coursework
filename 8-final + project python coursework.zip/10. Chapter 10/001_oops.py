# class Number:
#     def sum(self):
#         return self.a + self.b

# num = Number()

# num.a=12
# num.b=34
# s=num.sum()
# print(s)        

# class RailForm:
#     formType = "RailForm"
#     def printData(self):
#         print(f"Name is {self.name}")
#         print(f"Train is {self.train}")

# AlifsApplication = RailForm()
# AlifsApplication.name="Alif"
# AlifsApplication.train="Turna"
# AlifsApplication.printData()        

# class Remote:
#     pass

# class Player:
#     def moveRight(self):
#         pass
#     def moveLeft(self):
#         pass
#     def moveTop(self):
#         pass

# remote1 = Remote()
# player1 = Player()

# if(remote1.isLeftPresses()):
#     player1.moveLeft()


class Employee:
    company = "Google"
    def getSalary(self):
        print(f"Salary is {self.salary}")

    def __init__(self, name, salary, subunit):
        self.name=name
        self.salary=salary
        self.subunit=subunit
        print("Employee is created")    

Alif = Employee("Alif","100k","YouTube")

# print(Alif.company)
# print(Yana.company)    

# Employee.company='YouTube'

# print(Alif.company)
# print(Yana.company)

# Alif.company = Microsoft

# print(Alif.company)

# Alif.salary = 300

# # print(Alif.salary)

# Alif.getSalary()