# f = open('poems.txt')
# t=f.read()
# if 'twinkle' in t:
#     print("present")
# else:
#     print("Absent")
# f.close()

