f = open('sample.txt','r')
data=f.read()
print(data)
f.close