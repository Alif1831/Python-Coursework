f = open('another.txt', 'w')
f.write("I am writing") 
f.close()