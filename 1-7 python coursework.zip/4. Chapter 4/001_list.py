# a=[1,2,3,4,5,6]

# print(a[0])

# friends=("alif", "jisan", "sajid", "ovi" , "sifat")
# print(friends[0:2])

l=[1,3,6,2,8,9,4]
# l.sort()
# print(l)
# l.reverse()
# print(l)

l.append(45)
print(l)
