# a1=input("Enter Fruit Number 1")
# a2=input("Enter Fruit Number 2")
# a3=input("Enter Fruit Number 3")
# a4=input("Enter Fruit Number 4")
# a5=input("Enter Fruit Number 5")
# a6=input("Enter Fruit Number 6")
# a7=input("Enter Fruit Number 7")
# fl=[a1,a2,a3,a4,a5,a6,a7]
# print(fl)

a=[1,2,3,4,5]
print(sum(a))