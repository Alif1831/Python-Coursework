a = int(input("Enter your marks: "))

if a>=90:
    print("Excellent")
elif(a>=80):
    print("A")
elif(a>=70):
    print("B")
elif(a>=60):
    print("C")
elif(a>=50):
    print("D")
else:
    print("Fail")