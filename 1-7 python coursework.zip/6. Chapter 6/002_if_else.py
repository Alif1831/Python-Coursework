# age = int(input("Enter your age"))
# if age>18:
#     print("Yes")
# else:
#     print("No")    

a=[24,25,6]
print(26 in a)