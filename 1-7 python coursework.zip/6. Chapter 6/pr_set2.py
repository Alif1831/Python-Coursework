# comment=input("Enter the text")
# spam = False
# if("make a lot of money " in comment):
#     spam = True
# elif("buy now " in comment):
#     spam = True
# elif()

# a=input("Enter a name")
# if(len(a)<10):
#     print("less than 10")
# else:
#     print("greater than 10")

names = ["Alif","sajid","jisan","ovi","zarzis"]

a=input("Enter a name")
if(a in names):
    print("Present")
else:
    [print("absent")]