# a=int(input("Enter a Number: "))
# b=int(input("Enter a Number: "))
# c=int(input("Enter a Number: "))
# d=int(input("Enter a Number: "))

# if(a>b and a>c and a>d):
#     print("a is the largest")
# elif(b>a and b>c and b>d):
#     print("b is the largest")
# elif(c>a and c>b and c>d):
#     print("c is the largest")
# else:
#     print("d is the largest")

a=int(input("Enter first marks"))
b=int(input("Enter first marks"))
c=int(input("Enter first marks"))

if(a<33 or b<33 or c<33):
    print("Fail")
elif((a+b+c)/3 < 40):
    print("Fail")    
else:
    print("you passed")