a = int(input("Enter your marks: "))

if(a>=90 and a<=100):
    print("Excellent")
elif(a>=80 and a<90):
    print("A")
elif(a>=70 and a<80):
    print("B")
elif(a>=60 and a<70):
    print("C")
elif(a>=50 and a<60):
    print("D")
else:
    print("Fail")