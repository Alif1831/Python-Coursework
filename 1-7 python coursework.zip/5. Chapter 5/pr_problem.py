myDict={
    "pankha":"fan",
    "dabba":"box",
    "vastu":"obj"
}
print("The options are", myDict.keys())
a=input("Enter the hindi word")
print("The meaning of the word is",myDict.get(a))