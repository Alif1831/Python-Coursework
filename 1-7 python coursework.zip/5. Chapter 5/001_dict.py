myDict = {
    "Fast" : "In a quick manner",
    "Alif" : "A procastinator"
}
myDict["Fast"]=31,18
print(myDict["Fast"])