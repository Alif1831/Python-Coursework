# a={1,2,3,4}
# print(type(a))

b=set()
b.add(4)
b.add(5)
b.add((4,5,6))
print(b)

print(len(b))

print(b.pop())