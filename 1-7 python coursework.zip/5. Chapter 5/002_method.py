myDict = {
    "fast" : "in a quick manner",
    "alif" : "what"

}
print(list(myDict.keys()))
print(list(myDict.values()))

newDict={
    "coder" : "ha ha",
    "loser" : "in a sense"
    
}

myDict.update(newDict)
print(myDict)

print(myDict.get("alif2"))
print(myDict["alif"])