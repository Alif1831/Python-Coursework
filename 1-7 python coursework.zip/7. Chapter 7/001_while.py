# i = 0
# while i<=50:
#     print(i)
#     i=i+1

fruits=['Banana','melon','grape','mango']
i=0
while i<len(fruits):
    print(fruits[i])
    i=i+1