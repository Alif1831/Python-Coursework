# i = int(input("enter a number"))
# fact=1
# for j in range(1,i+1):
#     fact=fact*j

# print(fact)    

n=4
for i in range(4):
    print("*"*(i+1))