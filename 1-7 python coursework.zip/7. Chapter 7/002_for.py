# fruits=['a','b','c','d']
# for item in fruits:
#     print(item)

# for i in range(2,8,2): #start,stop,step
#     print(i)

# for i in range(10):
#     print(i)

# else:
#     print("this is inside else of for")

# for i in range(10):
#     print(i)
#     if i==5:
#         break

for i in range(10):
    if i==5:
        continue
    print(i)