# i=int(input("Enter a number"))
# j=0
# for j in range(10):
#     print(str(i)+"*"+str(j)+"="+str(i*j))

l1=["harry","suchan","alif","himel"]

for name in l1:
    if name.startswith("h"):
        print("Hello "+name)