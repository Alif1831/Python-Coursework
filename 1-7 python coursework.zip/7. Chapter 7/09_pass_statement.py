i = 4

def run(player):
    pass

def ouch(player):
    pass

if i>0:
    pass

while i>6:
  pass

print("Harry is a good boy")