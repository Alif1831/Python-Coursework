for i in range(1, 8, 1):
    print(i)