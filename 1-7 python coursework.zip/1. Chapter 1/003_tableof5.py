from playsound import playsound
playsound("D:\\CWH Python\\1. Chapter 1\\play.mp3")