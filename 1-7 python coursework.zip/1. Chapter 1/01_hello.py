'''
Author: Harry
Licenced to: ABC Company
***********Thanks for reading**********
'''
import os # importing the os module 
print("Hello world")