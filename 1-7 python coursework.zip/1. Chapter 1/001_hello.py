from importlib.machinery import all_suffixes
import os

'''author:alif 
icensed to : ABC company'''
#single line comment
'''multiline comment'''

print("Hello World")