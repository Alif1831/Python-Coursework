


a= '''harry'''
b=45
c=345.32
d= True

print(a)
print(b)
print(c)
print(d)

print(type(a))
print(type(b))
print(type(c))
print(type(d))

