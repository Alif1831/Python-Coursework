# a=input("Enter a number: ")
# b=input("Enter a number: ")
# x=int(a)
# y=int(b)
# sum=x+y

# print("The sum is: ",sum )25

# a=34
# b=80
# print(a>b)



a=input("Enter a number : ")
a=int(a)
sq=a*a
print("The square is",sq)