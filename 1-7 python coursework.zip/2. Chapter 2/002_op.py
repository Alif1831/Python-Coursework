bool1 = True
bool2 = False

#Logical Operators
bool1= True
bool2= False
print("The value of bool1 and bool2 is ",(bool1 and bool2))

a=31
type(a)