# a=input("Enter your name:\n ")
# print("Good morning,"+a)

# name=input("Enter the name:")
# date=input("Enter the date:")
# letter='''Dear <|name|>,
# You are selected!
# <|Date|>'''
# letter=letter.replace("<|name|>",name)
# letter=letter.replace("<|Date|>",date)
# print(letter)

# a="this is a string with double spaces"
# dp=a.find(" ")
# print(dp)

letter="Dear Alif, you need to stop giving less fs, period!"
print(letter)

formatted_letter="Dear Alif,\nyou need to stop giving less fs,\nperiod!"
print(formatted_letter)
