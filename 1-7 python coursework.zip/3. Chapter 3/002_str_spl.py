# greeting = "Good Morning "
# name="Harry"
# print(type(name))
# print(greeting + name)

# name="Harry"
# # print(name[0])

# # print(name[0:3]) #last exclude, first include
# #print(name[:4])
# print(name[-4:-1])

story="i am a mediocre person struggling to cope with the extraordinary"
print(len(story))
print(story.endswith("extraordinary"))
print(story.count("a"))
print(story.capitalize())
print(story.find("am"))
print(story.replace("I","Alif"))

